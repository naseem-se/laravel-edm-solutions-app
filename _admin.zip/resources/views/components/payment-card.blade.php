@props([
    'title' => '',
    'icon' => '',
    'count' => 0,
    'sub_title' => '',
])


<div class="border border-[#0000001A] rounded-lg px-6 py-4">
    <div>
        <div class="flex justify-between items-center pb-6">
            <h1 class="font-normal text-[#717182] text-[14px] leading-[24px] tracking-[0px]">{{ $title }}</h1>
            <div class="">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                    stroke="#155DFC" class="size-6">
                    <path stroke-linecap="round" stroke-linejoin="round"
                        d="M15 19.128a9.38 9.38 0 0 0 2.625.372 9.337 9.337 0 0 0 4.121-.952 4.125 4.125 0 0 0-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 0 1 8.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0 1 11.964-3.07M12 6.375a3.375 3.375 0 1 1-6.75 0 3.375 3.375 0 0 1 6.75 0Zm8.25 2.25a2.625 2.625 0 1 1-5.25 0 2.625 2.625 0 0 1 5.25 0Z" />
                </svg>
            </div>
        </div>
        <h1 class="font-normal text-[#0A0A0A] pb-3 text-[30px] leading-[36px] tracking-[0px]">{{ $count }}</h1>
        <h1 class="font-normal text-[#717182] pb-3 text-[16px] leading-[24px] tracking-[0px]">{{ $sub_title }}</h1>

    </div>
</div>
